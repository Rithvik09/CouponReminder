package application;
import javafx.application.Application; 
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Group;
import javafx.scene.Scene; 
import javafx.scene.control.*; 
import javafx.scene.layout.*; 
import javafx.event.ActionEvent; 
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.stage.Stage; 
import javafx.scene.image.*; 
import java.io.*;
import java.util.*;
public class CouponReminder extends Application{
	public void start(Stage s) {
		s.setTitle("CouponReminder");
		
		GridPane rootNode = new GridPane();
        rootNode.setPadding(new Insets(15));
        rootNode.setHgap(5);
        rootNode.setVgap(5);
        rootNode.setAlignment(Pos.CENTER);
        
        rootNode.add(new Label("Welcome to Coupon Reminder"), 5, 0);
        
        MenuItem item1 = new MenuItem("Add Coupon");
        MenuItem item2 = new MenuItem("Find Coupon");
        
        MenuButton menuButton = new MenuButton("What do you want to do?", null, item1, item2);
        
        rootNode.add(menuButton, 0, 0);
        
        item1.setOnAction(new item1Handler());
        item2.setOnAction(new item2Handler());
        
        Scene scene = new Scene(rootNode, 500, 200);
        s.setScene(scene);
		s.show();
        
	}
	public static void main(String[] args) {
		launch(args);
	}
	
	class item1Handler implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			try {
				
			}catch(Exception e1) {
				
			}
		}
		
	}
	
	class item2Handler implements EventHandler<ActionEvent>{
		public void handle(ActionEvent e) {
			try {
				
			}catch(Exception e1) {
				
			}
		}
		
	}
}
