package application;
import java.util.*; 
import java.io.*;
public class Coupon {
	private static Date ExpiryDate;
	private static String StoreName;
	private static Date ReminderDate;
	private static int PercentOff;
	private static int DollarOff;
	public Coupon(Date ED, String SN, Date RD, int PO, int DO) {
		ED = this.ExpiryDate;
		SN = this.StoreName;
		RD = this.ReminderDate;
		PO = this.PercentOff;
		DO = this.DollarOff;
	}
	
}
